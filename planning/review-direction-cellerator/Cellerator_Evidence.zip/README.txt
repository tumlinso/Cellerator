Cellerator research evidence companion
Reviewed 21 November 2026

Contents
  source_register.md: the report's C01-C11 and R01-R45 source references.
  source_manifest.json: source-service provenance, exact local snapshot hashes,
    remote full-file hashes, requested ranges, completeness flags and git state.
  cellerator_snapshot/: 32 retrieved source files or excerpts.

The Cellerator repository was accessed through Project Control. Its worktree
was dirty at commit fe12934a128741fde24cfbae5bcd5f3244cf01ae. Initial and final
git observations had the same status fingerprint. That does not identify all
working-tree bytes; use the per-file hashes.

These are exact UTF-8 copies of the content returned by the source service.
For 27 snapshots, the local hash matches the remote full-file hash. The other
five snapshots are excerpts or bounded responses. The manifest distinguishes
the requested line range from the actual local line count and requested-range
completeness from whole-file hash equality. The coding-style document was read
in overlapping ranges. Do not treat this archive as a complete or buildable
checkout.

No repository source was changed. No new build, GPU benchmark, biological
training run or dataset download was performed for the report. The recorded
Cellerator performance results retain their original qualification limits;
including a historical report here does not independently reproduce it.

External source links identify the primary papers, official documentation and
implementations inspected. Moving main/latest pages require a version pin
before an integration or reproducible benchmark. This archive does not bundle
third-party repositories or complete copyrighted publications.

Integrity audit: this companion makes the inspected source boundary auditable;
it cannot certify exhaustive source coverage, mathematical completeness,
software compatibility or scientific validity outside the stated evidence.
