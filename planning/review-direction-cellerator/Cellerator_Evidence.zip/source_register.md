## Evidence and source register

Sources were reviewed on 21 November 2026. Bracketed C codes identify inspected Cellerator records; R codes identify external primary papers, official documentation or source implementations. Several R entries group closely related documentation for one implementation. Moving main branches and latest documentation must be pinned before a reproducible integration. Numbers reported from Cellerator are historical measurements unless explicitly described as arithmetic derivations.

### Cellerator source records

Repository root: /home/tumlinson/Cellerator. The worktree was dirty at commit fe12934a128741fde24cfbae5bcd5f3244cf01ae. Initial and final git observations retained the same status fingerprint. This is not a clean-checkout build claim. The companion evidence archive contains the retrieved source snapshots and a machine-readable provenance manifest with full hashes, line ranges and observation timestamps. Excerpts are identified separately from full files.

**C01 Cellular geometry.** cellular_geometry.md. Governing meaning of admissible dependencies, eligibility, model coordinates, finite-time influence and scoped omission. Read in full.

**C02 Native scope and style.** AGENTS.md, scope.md and coding_style.md. Native backend scope, explicit provisioning, supplied storage, ownership, vendor boundaries and protected documents. The coding-style file was retrieved in overlapping ranges.

**C03 Native data and execution boundary.** docs/native_data.qmd. Borrowed ATen integration, identity and dependency contracts, retained values and bounded distributed gated-product behavior. Read in full.

**C04 Existing ggml bridge.** docs/ggml.qmd; cmake/CelleratorGGML.cmake; include/Cellerator/interop/ggml/quantization.hh. The guide hash begins f5b18bdc7287a813. The CMake pin is facdc44a67da17df4433adcc468b424f48e9ded2. These records distinguish CPU codec integration from unqualified package and GPU training claims.

**C05 Numerical representations.** include/Cellerator/tensor/block_masked/layout.hh; tensor/state_codes/view.hh; tensor/quantized/blocked_ell.hh; tensor/quantized/csr.hh; and include/Cellerator/interop/formats/cellpack.hh. All tensor paths are below include/Cellerator. Inspected descriptors and borrowing contracts establish payload meaning, not a complete consumer audit.

**C06 Gated product and derivative contracts.** include/Cellerator/ops/mechanism/gated_product.hh; packed_gated_product.cuh; access.hh; omission.hh. Hashes for the first two begin 272cc81445fe2498 and b433ca669854f784. Source supports the zero-safe product, C1 gate, phase demands and offset/gradient-buffer findings.

**C07 Shared regulatory support.** docs/learning/bio-design.md and docs/learning/bio-evidence/README.md. Hashes begin e4b904d08992eed9 and 51e7e2ad6fa912c0. They contain the model restriction, exact derivatives, historical iteration comparison and incomplete memory accounting. No new benchmark replay was performed.

**C08 Factorized interaction qualification.** planning/interaction-layout-proposal-2026-11-02/VALIDATION.md and PAUSED.md. Hashes begin d61cf8407ec7da07 and de1ca1fb42a86082. These describe the parent operation's bounded numerical evidence and paused performance work. They do not supersede the separate later prototype result C09.

**C09 Shared product circuit result.** bench/factorized_interactions/prototypes/shared_product_circuit/REPORT.md; evidence/independent-result-review.md; evidence/result-discussion.md. Hashes begin a5a77b3453667783, a4e917aadfaf97da and a8c6ffd2ed3824a7. They contain the 6.13% matched result, one-run limitations, unchanged oracle, and memory confounding of the native comparison. The source-bound report and review were inspected; original GPU execution was not independently rerun.

**C10 Chromatin study status.** planning/chromatin-geometry-study-2026-11-02/PAUSED.md, hash beginning a7ef8f3092309583. Retains the qualified bounded negative result, rejected timing conditions and latest pause boundary.

**C11 Current supported package.** docs/current_implementation.qmd, retrieved lines 1–235. The November 14 boundary retires scientific I/O and velocity integration from the supported package; the November 5 entry assigns compiler ownership to Texo. Older sections retain historical qualifications.

### External numerical implementations and methods

**R01 PyTorch derivative extension contracts.** [Extending torch.func with autograd.Function](https://docs.pytorch.org/docs/2.15/notes/extending.func.html). Separate backward, JVP, batching and transform-composition requirements. Version 2.15 documentation is a capability reference, not the project's qualified dependency.

**R02 NVIDIA sparse numerical primitives.** [cuSPARSE 12.9.1 API](https://docs.nvidia.com/cuda/archive/12.9.1/cusparse/index.html). SpMM, SDDMM, format/type restrictions and Blocked ELL transpose/index boundaries. [Official CUDA library samples](https://github.com/NVIDIA/CUDALibrarySamples/tree/master/cuSPARSE).

**R03 Dense and construction primitives.** [cuBLAS 12.9.2](https://docs.nvidia.com/cuda/archive/12.9.2/cublas/index.html); [CUDA Core Compute Libraries](https://github.com/NVIDIA/cccl); [CUTLASS functionality](https://docs.nvidia.com/cutlass/latest/media/docs/cpp/functionality.html); [CUTLASS license](https://github.com/NVIDIA/cutlass/blob/main/LICENSE.txt). Use compatible CUB/CUTLASS components and explicit provider contracts.

**R04 Sparse neural aggregation precedent.** [PyTorch Geometric memory-efficient aggregations](https://pytorch-geometric.readthedocs.io/en/latest/advanced/sparse_tensor.html). Describes conditions for eliminating explicit messages using sparse matrix multiplication.

**R05 ggml representation and consumers.** [Exact block structs](https://github.com/ggml-org/llama.cpp/blob/master/ggml/src/ggml-common.h); [CUDA decode routines](https://github.com/ggml-org/llama.cpp/blob/master/ggml/src/ggml-cuda/dequantize.cuh); [Build options and V100 tradeoff](https://raw.githubusercontent.com/ggml-org/llama.cpp/master/docs/build.md); [GGUF specification](https://github.com/ggml-org/ggml/blob/master/docs/gguf.md); [ggml project and license](https://github.com/ggml-org/ggml). The report's block-byte arithmetic follows the structs.

**R06 FBGEMM.** [Rowwise quantization utilities](https://docs.pytorch.org/FBGEMM/fbgemm/cpp-api/QuantUtils.html); [Table-batched embedding training](https://docs.pytorch.org/FBGEMM/fbgemm_gpu/python-api/tbe_ops_training.html); [Release compatibility](https://docs.pytorch.org/FBGEMM/general/Releases.html); [License](https://docs.pytorch.org/FBGEMM/general/License.html). Package architecture support is distinct from possible source builds.

**R07 bitsandbytes and low-bit training boundaries.** [Current autograd implementation](https://github.com/bitsandbytes-foundation/bitsandbytes/blob/main/bitsandbytes/autograd/_functions.py); [Installation capability matrix](https://huggingface.co/docs/bitsandbytes/installation); [8-bit Optimizers via Block-wise Quantization](https://arxiv.org/abs/2110.02861); [QLoRA](https://arxiv.org/abs/2305.14314); [License](https://github.com/bitsandbytes-foundation/bitsandbytes/blob/main/LICENSE). Frozen packed weights and trainable adapters are not arbitrary packed-weight differentiation.

**R08 Transformer Engine.** [Datatype and hardware support](https://docs.nvidia.com/deeplearning/transformer-engine/support_matrix.html); [Quantization recipe implementation](https://github.com/NVIDIA/TransformerEngine/blob/main/transformer_engine/common/recipe/__init__.py). Training-format and transpose costs must be measured on supported architectures.

**R09 CppAD sparse Jacobians.** [Sparse Jacobian API](https://cppad.readthedocs.io/latest/sparse_jac.html); [User guide and licensing](https://cppad.readthedocs.io/stable-2026/user_guide.html). Conservative sparsity, forward/reverse coloring and reusable work.

**R10 PETSc.** [MatCreateShell](https://petsc.org/release/manualpages/Mat/MatCreateShell/); [Field-split preconditioning](https://petsc.org/release/manualpages/PC/PCFIELDSPLIT/). Matrix-free actions, operator state notifications and Schur-complement/preconditioner machinery.

**R11 AMICI.** [Official capabilities](https://amici.readthedocs.io/en/latest/about.html); Froehlich et al., [High-performance sensitivity analysis for large ODE models](https://academic.oup.com/bioinformatics/article/37/20/3676/6209017), Bioinformatics 2021; [Author preprint](https://arxiv.org/abs/2012.09122). Compiled biological simulation and sensitivity analysis. [Conservation-law sensitivity API](https://amici.readthedocs.io/en/latest/_exhale_cpp_api/classamici_1_1Model.html).

**R12 SUNDIALS adjoint integration.** [CVODES 7.3 adjoint interface](https://sundials.readthedocs.io/en/v7.3.0/cvodes/Usage/ADJ.html). Checkpointed backward problems and reusable solver interfaces.

**R13 Ginkgo.** [Official project](https://ginkgo-project.github.io/); [Source](https://github.com/ginkgo-project/ginkgo); [Current documentation](https://gko-project.org/). Native sparse solvers across CPU and accelerators. Current documentation explicitly includes in-development 2.0 material; pin a released implementation for comparison.

**R14 KeOps.** [Official project](https://www.kernel-operations.io/keops/); [Automatic differentiation](https://www.kernel-operations.io/keops/api/autodiff.html). Formula-based pairwise reductions and derivative actions without a materialized pair matrix.

**R15 Distributional numerical libraries.** [GeomLoss](https://www.kernel-operations.io/geomloss/); [OTT-JAX low-rank Sinkhorn](https://ott-jax.readthedocs.io/solvers/_autosummary/ott.solvers.linear.sinkhorn_lr.LRSinkhorn.html); [OTT Sinkhorn differentiation](https://ott-jax.readthedocs.io/solvers/_autosummary/ott.solvers.linear.sinkhorn.Sinkhorn.html). Linear memory does not imply subquadratic arithmetic; low-rank coupling is a model approximation.

**R16 CellRank.** Weiler et al., [CellRank 2](https://www.nature.com/articles/s41592-024-02303-9), Nature Methods 2024; [Open text](https://pmc.ncbi.nlm.nih.gov/articles/PMC11239496/); [Implementation overview](https://cellrank.readthedocs.io/en/stable/about/index.html). Exact aggregation of requested terminal outcomes reduces the number of solves.

**R17 BEAGLE.** [Native tree-likelihood library](https://github.com/beagle-dev/beagle-lib); [C API](https://beagle-dev.github.io/html/beagle_8h.html). Cached partials, operation buffers and likelihood/gradient computation for its specified phylogenetic models.

**R18 CasADi.** [Documentation](https://web.casadi.org/docs/); [License](https://github.com/casadi/casadi/blob/main/LICENSE.txt); [Contribution and runtime guidance](https://github.com/casadi/casadi/blob/main/CONTRIBUTING.md). Sparse symbolic differentiation and code generation with component-specific licensing.

**R19 The Tensor Algebra Compiler.** [taco source and capabilities](https://github.com/tensor-compiler/taco). C++ sparse tensor expressions and code generation for CPU/GPU computations.

**R20 Finch.** [Finch.jl](https://github.com/finch-tensor/Finch.jl); [Structured tensor formats](https://finch-tensor.org/Finch.jl/stable/docs/tensor_formats/). A Julia compiler reference for exploiting sparse and other regular structure.

**R21 Factorized incremental computation.** [F-IVM implementation overview](https://fdbresearch.github.io/fivm-code.html); [Source](https://github.com/fdbresearch/FIVM). Query factorization and C++ update generation; applicability to training requires valid numeric dependencies.

**R22 Checkpointing.** [PyTorch checkpoint API](https://docs.pytorch.org/docs/2.15/checkpoint.html); [Activation checkpointing techniques](https://pytorch.org/blog/activation-checkpointing-techniques/). Save/recompute choices and their framework boundaries.

**R23 Dynamics algorithms.** [ARKODE inner-stepper interfaces](https://sundials.readthedocs.io/en/latest/arkode/Usage/User_callable.html); [Diffrax adjoints](https://docs.kidger.site/diffrax/api/adjoints/); Gholami et al., [ANODE](https://arxiv.org/abs/1902.10298). Multirate interfaces and distinctions among numerical sensitivity strategies.

**R24 Hybrid events.** Kong et al., [Saltation Matrices](https://arxiv.org/abs/2306.06862); [SciMLSensitivity contracts](https://docs.sciml.ai/SciMLSensitivity/dev/manual/differential_equation_sensitivities/). Event/reset derivatives and method-dependent support.

**R25 Optimizer semantics.** [PyTorch Adam and zero_grad](https://docs.pytorch.org/docs/2.15/generated/torch.optim.Adam.html). Zero gradients and absent gradients result in different update behavior.

**R26 Learned sparsity.** Evci et al., [Rigging the Lottery](https://proceedings.mlr.press/v119/evci20a.html), ICML 2020; Louizos et al., [Learning Sparse Neural Networks through L0 Regularization](https://arxiv.org/abs/1712.01312). Candidate growth and stochastic gate policies, not biological exclusion certificates.

### Hardware and scientific evidence

**R27 NVIDIA architecture support.** [CUDA 13.0 Update 3 release notes](https://docs.nvidia.com/cuda/archive/13.0.3/cuda-toolkit-release-notes/index.html); [Volta tuning](https://docs.nvidia.com/cuda/volta-tuning-guide/); [Ampere tuning](https://docs.nvidia.com/cuda/archive/12.9.1/ampere-tuning-guide/index.html); [Hopper tuning](https://docs.nvidia.com/cuda/archive/12.9.1/hopper-tuning-guide/index.html). Toolkit support and compute capabilities are distinct from runtime scientific qualification.

**R28 PyTorch build compatibility.** [Upstream release matrix](https://github.com/pytorch/pytorch/blob/main/RELEASE.md); [Pre-Turing binary-support removal discussion](https://github.com/pytorch/pytorch/issues/190385). Snapshot of upstream version/architecture policy, not an inspection of Cellerator's installed LibTorch.

**R29 Specialized provider boundaries.** [Triton supported platforms](https://github.com/triton-lang/triton); [cuSPARSELt requirements](https://docs.nvidia.com/cuda/cusparselt/getting_started.html); [Sputnik](https://github.com/google-research/sputnik); [Sputnik paper](https://arxiv.org/abs/2006.10901). Current GPU minima and archived-source considerations.

**R30 Strong simple perturbation baselines.** Ahlmann-Eltze, Huber and Anders, [Deep-learning-based gene perturbation effect prediction does not yet outperform simple linear baselines](https://www.nature.com/articles/s41592-025-02772-6), Nature Methods 2025. Findings are bounded to the studied models, datasets, tasks and metrics.

**R31 Metric calibration and counterevidence.** Miller et al., [Deep learning perturbation models can outperform baselines on calibrated metrics](https://www.nature.com/articles/s41587-026-03307-w), Nature Biotechnology, 1 October 2026; [PubMed record](https://pubmed.ncbi.nlm.nih.gov/42823510/). Fourteen datasets, eighteen metrics; observed-cell duplicate controls do not establish unseen-context prediction.

**R32 Scaling evidence.** DenAdel et al., [Evaluating the role of pretraining dataset size and diversity on single-cell foundation model performance](https://www.nature.com/articles/s41592-026-03120-y), Nature Methods 2026. Four hundred pretrained models and 6,400 evaluations; bounded empirical saturation rather than a universal impossibility result.

**R33 Generalization benchmark infrastructure.** [Benchmarking algorithms for generalizable single-cell perturbation response prediction](https://www.nature.com/articles/s41592-025-02980-0), Nature Methods 2026; [scPerturBench source](https://github.com/bm2-lab/scPerturBench/). Multiple datasets, methods and generalization scenarios.

**R34 Probabilistic observation and velocity consumers.** [scVI 1.3.3 model](https://docs.scvi-tools.org/en/1.3.3/user_guide/models/scvi.html); [MultiVI](https://docs.scvi-tools.org/en/latest/user_guide/models/multivi.html); [totalVI](https://docs.scvi-tools.org/en/stable/tutorials/notebooks/multimodal/totalVI.html); [veloVI paper](https://www.nature.com/articles/s41592-023-01994-w). These supply scientific model contracts, not proof of Cellerator acceleration.

**R35 Biological transport.** [moscot paper](https://www.nature.com/articles/s41586-024-08453-2); [User guide](https://moscot.readthedocs.io/en/latest/user_guide.html). Temporal/spatial/multimodal transport as a numerical consumer.

**R36 Lineage and history resources.** [LARRY study](https://pmc.ncbi.nlm.nih.gov/articles/PMC7608074/); [MELA 2026 release](https://github.com/jweissmanlab/MELA-2026); [NextCell](https://next-cell.org/); [Cassiopeia](https://github.com/YosefLab/Cassiopeia). Reconstructed ancestry is not direct observation of ancestral expression. Counts and scope must follow the pinned release.

**R37 Batch removal and biological preservation.** Luecken et al., [Benchmarking atlas-level data integration in single-cell genomics](https://www.nature.com/articles/s41592-021-01336-8), Nature Methods 2022; [PubMed](https://pubmed.ncbi.nlm.nih.gov/34949812/).

**R38 Data and simulation controls.** [scPerturb](https://www.nature.com/articles/s41592-023-02144-y); [SERGIO](https://github.com/PayamDiba/SERGIO); [BEELINE](https://www.nature.com/articles/s41592-019-0690-6). Harmonized observations and simulations serve different validation roles.

**R39 Scientific compression.** [zfp compression modes](https://zfp.readthedocs.io/en/latest/modes.html); [SZ3](https://github.com/szcompressor/SZ3). Storage/accuracy contracts are not guarantees about downstream derivatives or dynamics.

**R40 Communication primitives.** [NCCL point-to-point operations](https://docs.nvidia.com/deeplearning/nccl/user-guide/docs/usage/p2p.html); [Grouped operations](https://docs.nvidia.com/deeplearning/nccl/user-guide/docs/usage/groups.html). Reuse transport machinery while defining Cellerator's ownership, scheduling and derivative traffic.

**R41 Modular implicit differentiation.** Blondel et al., [Efficient and Modular Implicit Differentiation](https://arxiv.org/abs/2105.15183). Solver and optimality-condition separation. [JAXopt repository](https://github.com/google/jaxopt) is an algorithmic reference; its maintenance status precludes treating it as an unquestioned new core dependency.

**R42 Enzyme.** Moses et al., [Reverse-Mode Automatic Differentiation and Optimization of GPU Kernels via Enzyme](https://sc21.supercomputing.org/proceedings/tech_paper/tech_paper_pages/pap242.html), SC 2021; [CUDA guide](https://enzyme.mit.edu/getting_started/CUDAGuide/). The guide's dated experimental status limits direct integration claims.

**R43 GraphBLAS.** [SuiteSparse GraphBLAS](https://github.com/DrTimothyAldenDavis/GraphBLAS); [Source license](https://github.com/DrTimothyAldenDavis/GraphBLAS/blob/stable/LICENSE). Structural masks and sparse/bitmap/dense execution are useful precedents; arbitrary differentiable GPU support is not inferred.

**R44 TorchAO direction.** [Current repository README](https://github.com/pytorch/ao/blob/main/README.md). Describes maintained existing workflows and the migration of low-level work toward PyTorch and high-level work toward consumers.

**R45 Frozen-weight quantization references.** [GPTQ](https://github.com/IST-DASLab/gptq); [AWQ](https://github.com/mit-han-lab/llm-awq); [HQQ](https://github.com/dropbox/hqq); [Marlin](https://github.com/IST-DASLab/marlin). Calibration/approximation algorithms and packed kernels have different contracts and hardware requirements.
