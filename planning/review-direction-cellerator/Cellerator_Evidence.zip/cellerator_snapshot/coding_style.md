# Cellerator C++ coding style

Cellerator uses compact, explicit numerical and systems code in the tradition
of classic C and Fortran scientific libraries.

**Use the compact form by default. Expose the calculation clearly.** These are
simultaneous requirements. Achieve clarity through precise notation,
mathematical grouping, deliberate layout, and direct program structure.
Additional source must contribute concrete computational or contractual meaning.

Source must expose the algorithm, memory layout, and execution through arrays,
pointers, indices, loops, arithmetic, and deliberate function calls. Use short
mathematical notation to make the calculation recognizable and keep related
work in view.

This governs how programs are understood, independently of performance.
Explicitness means making important operations visible. Concise code must be
backed by a precise account of what it asks the machine to do. Use C++ features
to express useful structure and remove repetition while preserving that
visibility. Keep dependencies and library machinery minimal.

## Authority and protection

Read this document before C++ design, implementation, or style review in
Cellerator, including CUDA C++. It is protected contributor authority.
**Do not change, rewrite, weaken, replace, move, or remove `coding_style.md`,
or weaken its protection in `AGENTS.md`, unless the user explicitly authorizes
that specific change.** A general implementation, cleanup, documentation, or
refactoring request does not grant that authorization. Report conflicts with
other guidance, tooling, or implementation to the user; do not silently revise
these rules to match. Keep the rendered include faithful to this canonical
root text.

Apply these rules within the authorized task. They do not authorize broad
refactoring or changes to biological semantics, numerical contracts, ownership,
or execution authority. Those remain governed by the repository's architecture
and operation-specific contracts.

## Scope and dependencies

These rules cover all authored native production code: public interfaces,
templates, examples, host preparation and planners, resource owners, runtime
machinery, CPU calculations, and CUDA kernels. Host code, cold paths, and
placement in a Cellerator class are not exemptions. Cellerator owns reusable
numerical, storage, layout, execution, derivative, and modeling abstractions;
those abstractions must preserve the same direct computational style.

No STL machinery: no containers, algorithms, smart pointers, type-erased
callables, or equivalent machinery concealed behind another name. This includes
vector, map, set, tuple, variant, string, optional, span, ranges, function, or
generic growing-container replacement. Use visible fields, pointers, counts,
capacities, indices, and explicit initialization. Reuse existing Cellerator owners and views where
their contracts fit; do not duplicate them in a consumer or replace prohibited
STL with another general-purpose framework.

Use the smallest necessary scalar headers: stddef.h, stdint.h, and float.h.
Prefer compiler math and memory builtins. Audit authored transitive includes
as well as direct ones. Necessary platform, CUDA/intrinsic, and vendor API
declarations belong at their concrete implementation or adapter boundary;
foreign API-mandated types may appear only where that API requires them.
These exceptions do not license STL-backed internal planning or storage.
Development-only tests, tooling, and measurement infrastructure may use ordinary
library facilities. Third-party implementations follow their own rules. Keep
those dependencies out of the authored core except at the stated boundaries.

Existing noncompliant source is migration debt, not precedent or an exception.
New and reworked code must comply. Fix the affected computation and necessary
callers within the authorized task; unrelated repository-wide cleanup is not
a prerequisite for using an existing interface or completing scoped work.

## Expressions and mathematical notation

- Use `?:` for value selection, including initialization, arguments, and
  returns. Use a Boolean expression directly when it already gives the result:
  `return i < n;`.
- Express short piecewise definitions as linear ternary chains. Align cases
  that benefit from separate lines. Express distinct actions and sequencing
  with direct control flow, keeping the branch structure visible.
- Keep mathematical expressions whole: `y[i] = a*x[i] + b*y[i];`. Introduce a
  temporary for reuse, a meaningful intermediate quantity, an explicit
  conversion, numerical staging, or a dependency that benefits from a name.
- Do not expand straightforward calculations into named arithmetic steps,
  verbose local names, repetitive statements, or forwarding helpers. Introduce
  intermediate quantities for reuse, mathematical significance, or required
  evaluation semantics. Keep the calculation recognizable as a whole.
- Use conventional arithmetic and compound assignments where their semantics
  fit. Each expression must have traceable effects and defined sequencing.
  Parenthesize grouping that would otherwise require deciphering precedence.

These examples show the default forms:

```cpp
const int step = reverse ? -1 : 1;
int sign(int k) { return k < 0 ? -1 : k > 0 ? 1 : 0; }
```

Condensing an expression must preserve its numerical and language semantics:
types, conversions, rounding where required, evaluation dependencies, aliasing,
and lifetimes. Retain useful temporaries rather than repeat a computation.
A ternary evaluates its selected arm, while both arms participate in determining
its result type and value category. It is no promise of branchless execution.

## Names, declarations, and types

- Use short names tied to established notation: `i`, `j`, `k`, `m`, `n`, `lda`,
  `dt`, `r`, and `p` are precise in a clear local context. Give broader interfaces
  enough naming context to stand alone.
- Group related scalar declarations, such as `int m = a.rows, n = a.cols;`.
  Keep pointer and reference declarations individually clear. Group statements
  by their role in the calculation.
- Show consequential numeric types, index widths, and conversions. Keep storage,
  multiply, accumulation, and output types explicit where they differ, following
  the numerical policy and the operation's contract.
- Use `auto`, `auto &`, and `auto *` deliberately. Make the distinction between
  a value, an alias, and a pointer apparent, especially where a value declaration
  would copy owned storage.
- For known arithmetic types, use short conversions such as `double(n)` and
  `float(x)`. Use named casts where pointer interpretation, qualifiers, or class
  relationships deserve attention.
- Use short namespace aliases and useful type aliases to simplify repeated
  notation. Their meaning and numerical or ownership consequences must remain
  easy to find. Scalar declarations do not authorize broad runtime headers.

## Control flow and function boundaries

- Keep simple guards, loops, and short functions compact, using one-line forms
  as the default. Omit braces for unambiguous single-statement bodies; use braces
  for multiple statements or grouping that needs to be visible. Preserve
  unambiguous `else` association.
- Use early returns and `continue` where they keep the ordinary path flat and
  reduce the state a reader must remember.
- Group tightly coupled short statements, such as `x += dx; y += dy;`. Use
  conventional pointer idioms such as `*q++ = *p++;` for pointer advancement.
  Preserve valid extents and the aliasing contract.
- Keep a coherent algorithm together. There is no function-length quota.
  Extract functions for useful operations, reusable computations, or distinct
  contracts. Split at meaningful behavioral boundaries rather than to satisfy
  a line count.
- Ordinary labels and `goto` may expose phases, retries, cleanup, or exits
  from nested loops. Computed goto is a documented compiler extension confined
  to compiled implementation functions. Keep targets local and obey object
  initialization, lifetime, and destruction rules.

For example:

```cpp
if (!n) return;
for (int i = 0; i < n; ++i) y[i] += a*x[i];
```

## Data, ownership, and abstraction

- Use plain structs, direct data access, and free functions for plain data
  and computations. Give classes responsibility for ownership or real
  invariants. Getters, setters, factories, and inheritance need a concrete
  purpose.
- Keep owners and borrowed views distinct. Make pointer stability, extents,
  strides, layout, and lifetimes understandable from the interface and code.
  Allocation, copying, conversion, transfer, synchronization, and runtime
  dispatch must be apparent through clear owners and deliberate calls.
- Separate explicit resource provisioning from numerical work. Sizing,
  validation, numerical preparation, binding, and evaluation use supplied
  storage. Cheap stack descriptors and borrowed views are permitted; they do
  not acquire owners, materialize data, or allocate bookkeeping.
- Establish contracts at boundaries and let internal routines rely on those
  documented preconditions. Recheck facts when mutation or a new boundary can
  invalidate them. Preserve useful compiler-visible information about valid
  types, ranges, alignment, and aliasing; assert only guarantees the contract
  actually provides.
- Use small templates, callable structs, local lambdas, and `if constexpr` to
  express genuine common structure and useful specialization. Introduce
  runtime polymorphism, registration, or policy machinery only for a concrete
  in-scope computational contract that simpler direct code cannot express.
  Prefer typed function pointers with explicit caller state at deliberate
  operation boundaries; keep type erasure and dispatch out of element loops.
- Allow deliberate duplication whe